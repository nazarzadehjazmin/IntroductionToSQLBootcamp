#######################################################
#######################################################
############    COPYRIGHT - DATA SOCIETY   ############
#######################################################
#######################################################

## INTRODUCTION TO SQL PART1 ##

## NOTE: To run individual pieces of code, select the line of code and
##       press ctrl + enter for PCs or command + enter for Macs


#=================================================-
#### Slide 37: Exercise 1  ####




#=================================================-
#### Slide 47: CAST or CONVERT  ####

-- Convert the string "2017-09-21" to date type.
SELECT CAST("2017-09-21" AS DATE) AS date;
-- Convert the int 150 to char type.
SELECT CONVERT(150, CHAR) AS int_to_char;


#######################################################
####  CONGRATULATIONS ON COMPLETING THIS MODULE!   ####
#######################################################
